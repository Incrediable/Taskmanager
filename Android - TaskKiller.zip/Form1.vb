﻿Public Class Form1

    Private Sub Form1_KeyDown(sender As Object, e As KeyEventArgs) Handles Me.KeyDown
        If e.KeyCode = Keys.F5 Then loadProcesses()
    End Sub

    Private Sub Form1_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        loadProcesses()
    End Sub

    Sub loadProcesses()
        If ListView1.InvokeRequired Then
            ListView1.Invoke(New MethodInvoker(Sub()
                                                   ListView1.Items.Clear()
                                               End Sub))
        Else
            ListView1.Items.Clear()
        End If
        ImageList1.Images.Clear()
        ImageList1.Images.Add("NoIconFound", My.Resources.NoIconFound)

        For Each p As Process In Process.GetProcesses
            Try
                ImageList1.Images.Add(p.ProcessName, Icon.ExtractAssociatedIcon(p.MainModule.FileName))
                If ListView1.InvokeRequired Then
                    ListView1.Invoke(New MethodInvoker(Sub()
                                                           With ListView1.Items.Add(p.ProcessName, p.ProcessName)
                                                               .SubItems.Add(p.Id.ToString)
                                                               .SubItems.Add(p.MainWindowTitle)
                                                               .SubItems.Add(p.MainModule.FileName)
                                                           End With
                                                       End Sub))
                Else
                    With ListView1.Items.Add(p.ProcessName, p.ProcessName)
                        .SubItems.Add(p.Id.ToString)
                        .SubItems.Add(p.MainWindowTitle)
                        .SubItems.Add(p.MainModule.FileName)
                    End With
                End If
            Catch ex As Exception
                If ListView1.InvokeRequired Then
                    ListView1.Invoke(New MethodInvoker(Sub()
                                                           With ListView1.Items.Add(p.ProcessName, "NoIconFound")
                                                               .SubItems.Add(p.Id.ToString)
                                                               .SubItems.Add("")
                                                               .SubItems.Add("")
                                                           End With
                                                       End Sub))
                Else
                    With ListView1.Items.Add(p.ProcessName, "NoIconFound")
                        .SubItems.Add(p.Id.ToString)
                        .SubItems.Add("")
                        .SubItems.Add("")
                    End With
                End If
            End Try
        Next
        ListView1.AutoResizeColumns(ColumnHeaderAutoResizeStyle.ColumnContent)
    End Sub

    Private Sub listView1_ItemDrag(ByVal sender As Object, ByVal e As ItemDragEventArgs) Handles ListView1.ItemDrag
        ListView1.DoDragDrop(ListView1.SelectedItems, DragDropEffects.Move)
    End Sub

    Private Sub _DragDrop(sender As Object, e As DragEventArgs) Handles Panel1.DragDrop, Label1.DragDrop
        If e.Data.GetDataPresent(GetType(ListView.SelectedListViewItemCollection).ToString(), False) Then
            Dim lstViewColl As ListView.SelectedListViewItemCollection = CType(e.Data.GetData(GetType(ListView.SelectedListViewItemCollection)), ListView.SelectedListViewItemCollection)
            For Each lvItem As ListViewItem In lstViewColl
                Dim p As Process = Process.GetProcessById(Val(lvItem.SubItems(1).Text))
                Try
                    p.CloseMainWindow()
                    p.Kill()
                    p.WaitForExit(1000)
                Catch ex As Exception
                    MsgBox("Error killing process " + lvItem.Text + vbCrLf + vbCrLf + ex.ToString, vbCritical + vbOKOnly, "Error")
                End Try
            Next
        End If
    End Sub

    Private Sub _DragEnter(sender As Object, e As DragEventArgs) Handles Panel1.DragEnter, Label1.DragEnter
        If e.Data.GetDataPresent(GetType(ListView.SelectedListViewItemCollection)) Then
            e.Effect = DragDropEffects.Move
        End If
    End Sub

    Private Sub listView1_GiveFeedback(ByVal sender As Object, ByVal e As GiveFeedbackEventArgs) Handles ListView1.GiveFeedback
        e.UseDefaultCursors = False
        If (e.Effect And DragDropEffects.Move) = DragDropEffects.Move Then
            Cursor.Current = Cursors.SizeAll
        Else
            Cursor.Current = Cursors.Default
        End If
    End Sub

    Private Sub startWatch_EventArrived(sender As Object, e As Management.EventArrivedEventArgs)
        Dim p As Process = Process.GetProcessById(Convert.ToInt32(e.NewEvent.Properties("ProcessID").Value))
        Try
            ImageList1.Images.Add(p.ProcessName, Icon.ExtractAssociatedIcon(p.MainModule.FileName))
            If ListView1.InvokeRequired Then
                ListView1.Invoke(New MethodInvoker(Sub()
                                                       With ListView1.Items.Add(p.ProcessName, p.ProcessName)
                                                           .SubItems.Add(p.Id.ToString)
                                                           .SubItems.Add(p.MainWindowTitle)
                                                           .SubItems.Add(p.MainModule.FileName)
                                                       End With
                                                   End Sub))
            Else
                With ListView1.Items.Add(p.ProcessName, p.ProcessName)
                    .SubItems.Add(p.Id.ToString)
                    .SubItems.Add(p.MainWindowTitle)
                    .SubItems.Add(p.MainModule.FileName)
                End With
            End If
        Catch ex As Exception
            If ListView1.InvokeRequired Then
                ListView1.Invoke(New MethodInvoker(Sub()
                                                       With ListView1.Items.Add(p.ProcessName, "NoIconFound")
                                                           .SubItems.Add(p.Id.ToString)
                                                           .SubItems.Add("")
                                                           .SubItems.Add("")
                                                       End With
                                                   End Sub))
            Else
                With ListView1.Items.Add(p.ProcessName, "NoIconFound")
                    .SubItems.Add(p.Id.ToString)
                    .SubItems.Add("")
                    .SubItems.Add("")
                End With
            End If
        End Try
        ListView1.AutoResizeColumns(ColumnHeaderAutoResizeStyle.ColumnContent)
    End Sub

    Private Sub stopWatch_EventArrived(sender As Object, e As Management.EventArrivedEventArgs)
        Dim p As Process = Process.GetProcessById(Convert.ToInt32(e.NewEvent.Properties("ProcessID").Value))
        Try
            If ListView1.InvokeRequired Then
                ListView1.Invoke(New MethodInvoker(Sub()
                                                       For Each item As ListViewItem In ListView1.Items
                                                           If item.SubItems(1).Text = p.Id.ToString Then item.Remove()
                                                       Next
                                                   End Sub))
            Else
                For Each item As ListViewItem In ListView1.Items
                    If item.SubItems(1).Text = p.Id.ToString Then item.Remove()
                Next
            End If
        Catch ex As Exception
            If ListView1.InvokeRequired Then
                ListView1.Invoke(New MethodInvoker(Sub()
                                                       For Each item As ListViewItem In ListView1.Items
                                                           If item.SubItems(1).Text = p.Id.ToString Then item.Remove()
                                                       Next
                                                   End Sub))
            Else
                For Each item As ListViewItem In ListView1.Items
                    If item.SubItems(1).Text = p.Id.ToString Then item.Remove()
                Next
            End If
        End Try
        ListView1.AutoResizeColumns(ColumnHeaderAutoResizeStyle.ColumnContent)
    End Sub

    Private Sub ListView1_KeyDown(sender As Object, e As KeyEventArgs) Handles ListView1.KeyDown
        If e.KeyCode = Keys.Delete Then
            If ListView1.SelectedItems.Count > 0 Then
                For Each item As ListViewItem In ListView1.SelectedItems
                    Dim p As Process = Process.GetProcessById(Val(item.SubItems(1).Text))
                    Try
                        p.CloseMainWindow()
                        p.Kill()
                        p.WaitForExit(1000)
                    Catch ex As Exception
                        MsgBox("Error killing process " + item.Text + vbCrLf + vbCrLf + ex.ToString, vbCritical + vbOKOnly, "Error")
                    End Try
                Next
            End If
        End If
    End Sub

    Private Sub processChecker_Tick(sender As Object, e As EventArgs) Handles processChecker.Tick
        For Each p As Process In Process.GetProcesses
            Dim exists As Boolean = False
            For Each item As ListViewItem In ListView1.Items
                If item.SubItems(1).Text = p.Id.ToString Then exists = True
            Next
            If Not exists Then
                Try
                    ImageList1.Images.Add(p.ProcessName, Icon.ExtractAssociatedIcon(p.MainModule.FileName))
                    If ListView1.InvokeRequired Then
                        ListView1.Invoke(New MethodInvoker(Sub()
                                                               With ListView1.Items.Add(p.ProcessName, p.ProcessName)
                                                                   .SubItems.Add(p.Id.ToString)
                                                                   .SubItems.Add(p.MainWindowTitle)
                                                                   .SubItems.Add(p.MainModule.FileName)
                                                               End With
                                                           End Sub))
                    Else
                        With ListView1.Items.Add(p.ProcessName, p.ProcessName)
                            .SubItems.Add(p.Id.ToString)
                            .SubItems.Add(p.MainWindowTitle)
                            .SubItems.Add(p.MainModule.FileName)
                        End With
                    End If
                Catch ex As Exception
                    If ListView1.InvokeRequired Then
                        ListView1.Invoke(New MethodInvoker(Sub()
                                                               With ListView1.Items.Add(p.ProcessName, "NoIconFound")
                                                                   .SubItems.Add(p.Id.ToString)
                                                                   .SubItems.Add("")
                                                                   .SubItems.Add("")
                                                               End With
                                                           End Sub))
                    Else
                        With ListView1.Items.Add(p.ProcessName, "NoIconFound")
                            .SubItems.Add(p.Id.ToString)
                            .SubItems.Add("")
                            .SubItems.Add("")
                        End With
                    End If
                End Try
            End If
        Next
        For Each item As ListViewItem In ListView1.Items
            Try
                Dim p As Process = Process.GetProcessById(Convert.ToInt32(item.SubItems(1).Text))
            Catch ex As Exception
                item.Remove()
            End Try
        Next
        ListView1.AutoResizeColumns(ColumnHeaderAutoResizeStyle.ColumnContent)
    End Sub
End Class
