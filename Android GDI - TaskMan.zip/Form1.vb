﻿Public Class Form1

    'Creator: bilel bho
    'Site: elitevs.net
    'Created: 28/09/2015
    'Changed: 01/10/2015
    'Version: 1.1.0
    'Made In Tunisia

    Private pt As New Point(0, 0)

    Private dwn As Boolean = False
    Private Sub Form1_MouseDown(ByVal sender As System.Object, ByVal e As System.Windows.Forms.MouseEventArgs) Handles MyBase.MouseDown
        dwn = True
    End Sub

    Private Sub Form1_MouseUp(ByVal sender As System.Object, ByVal e As System.Windows.Forms.MouseEventArgs) Handles MyBase.MouseUp
        dwn = False
    End Sub
    Private Sub Form1_MouseMove(ByVal sender As Object, ByVal e As System.Windows.Forms.MouseEventArgs) Handles Me.MouseMove
        If (dwn = True) Then
            pt = e.Location
        End If
        Me.Invalidate()
    End Sub

    Dim g As Graphics
    Private Sub Form1_Paint(ByVal sender As Object, ByVal e As System.Windows.Forms.PaintEventArgs) Handles Me.Paint
        g = e.Graphics
        g.Clear(Color.White)
        g.DrawImage(My.Resources.Untitled_1, New Rectangle(0, 0, 307, 400))
        If (ProcessList.Count > 0) Then
            For i As Integer = 0 To ProcessList.Count - 1
                Dim img As Bitmap = ProcessList(i).mybmp
                Dim loc As New PointF(ProcessList(i).locX, i * img.Height)
                Dim snaprect As New Rectangle(loc.X + 150, loc.Y + 10, 128, 100)
                If (dwn = True) And (((pt.X >= snaprect.X) And (pt.X <= (snaprect.X + snaprect.Width))) And ((pt.Y >= snaprect.Y) And (pt.Y <= (snaprect.Y + snaprect.Height)))) Then
                    loc.X = CInt((pt.X - (180)))
                    If ProcessList(i).op > 0 Then
                        ProcessList(i).op = ProcessList(i).op - 1
                    End If
                Else
                    If loc.X > 6 Then
                        loc.X = loc.X - 6
                    ElseIf loc.X < 0 Then
                        loc.X = loc.X + 6
                    End If
                    If ProcessList(i).op < 100 Then
                        ProcessList(i).op = ProcessList(i).op + 1
                    End If
                End If
                If (loc.X > 250) Or (loc.X < -250) Then
                    ProcessList(i).out = True
                    ProcessList.Remove(ProcessList(i))
                    Exit Sub
                End If
                img = ChangeOpacity(img, ProcessList(i).op / 100)
                g.DrawImage(img, New Rectangle(loc.X, i * img.Height, img.Width, img.Height))
                ProcessList(i).locX = loc.X
            Next
        End If
    End Sub
    Public Declare Function IsWindowVisible Lib "user32.dll" (ByVal hwnd As IntPtr) As Boolean
    Private Declare Function GetWindowText Lib "user32" Alias "GetWindowTextA" (ByVal hwnd As Integer, ByVal lpWindowText As String, ByVal cch As Integer) As Integer
    Dim ProcessList As New List(Of cell)
    Private Sub Form1_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        Control.CheckForIllegalCrossThreadCalls = False
        For Each p As Process In Process.GetProcesses
            Dim tet As String = Space(Int16.MaxValue)
            Dim tetx As String = Space(Int16.MaxValue)
            Try


                If (p.MainWindowTitle <> "") Then
                    Dim c As New cell(p.Id, getbgimg(p.MainWindowHandle), Icon.ExtractAssociatedIcon(p.MainModule.FileName), p.MainWindowTitle)
                    ProcessList.Add(c)
                End If
            Catch : End Try
        Next
        ProcessList.Reverse()
        Dim t As New Threading.Thread(AddressOf anim)
        t.IsBackground = True
        t.SetApartmentState(Threading.ApartmentState.STA)
        t.Start()
    End Sub

    Sub anim()
        While True
            'Threading.Thread.Sleep(10)
            Me.Invalidate()
        End While
    End Sub

End Class



