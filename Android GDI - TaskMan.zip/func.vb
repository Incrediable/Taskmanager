﻿Imports System.Runtime.InteropServices
Imports System.Drawing.Imaging

'Creator: bilel bho
'Site: elitevs.net
'Created: 28/09/2015
'Changed: 01/10/2015
'Version: 1.1.0
'Made In Tunisia


Module func

    Const SRCCOPY As Integer = &HCC0020

    <DllImport("user32.dll")> _
    Private Function GetDC(ByVal hWnd As IntPtr) As IntPtr
    End Function

    <DllImport("user32.dll")> _
    Private Function ReleaseDC(ByVal hWnd As IntPtr, ByVal hDC As IntPtr) As Integer
    End Function

    <DllImport("gdi32.dll")> _
    Private Function BitBlt(ByVal hdcDest As IntPtr, ByVal xDest As Integer, ByVal yDest As Integer, ByVal wDest As Integer, ByVal hDest As Integer, ByVal hdcSource As IntPtr, ByVal xSrc As Integer, ByVal ySrc As Integer, ByVal rop As System.Int32) As Boolean
    End Function

    <DllImport("user32.dll", CharSet:=CharSet.Auto)> _
    Private Function GetClientRect(ByVal hWnd As System.IntPtr, ByRef lpRECT As RECT) As Integer
    End Function

    Public Function getbgimg(ByVal hwNd As IntPtr) As Bitmap
        Dim thmb As New Bitmap(128, 100)
        Dim gthmb As Graphics = Graphics.FromImage(thmb)
        gthmb.Clear(Color.FromArgb(180, Color.Black))
        Dim c As IntPtr = Nothing
        c = GetDC(hwNd)
        Dim rc As RECT
        GetClientRect(hwNd, rc)
        If (rc.Width > 0) And (rc.Height > 0) Then
            Dim pic As New Bitmap(rc.Width, rc.Height)
            Dim g As Graphics = Graphics.FromImage(pic)

            BitBlt(g.GetHdc, 0, 0, pic.Width, pic.Height, c, 0, 0, SRCCOPY)
            ReleaseDC(hwNd, c)
            g.ReleaseHdc()
            gthmb.DrawImage(pic, New Rectangle(0, 0, 128, 100))
        End If
        Return thmb
    End Function

    <StructLayout(LayoutKind.Sequential)> _
    Public Structure RECT
        Private _Left As Integer, _Top As Integer, _Right As Integer, _Bottom As Integer

        Public Sub New(ByVal Rectangle As Rectangle)
            Me.New(Rectangle.Left, Rectangle.Top, Rectangle.Right, Rectangle.Bottom)
        End Sub
        Public Sub New(ByVal Left As Integer, ByVal Top As Integer, ByVal Right As Integer, ByVal Bottom As Integer)
            _Left = Left
            _Top = Top
            _Right = Right
            _Bottom = Bottom
        End Sub

        Public Property X As Integer
            Get
                Return _Left
            End Get
            Set(ByVal value As Integer)
                _Right = _Right - _Left + value
                _Left = value
            End Set
        End Property
        Public Property Y As Integer
            Get
                Return _Top
            End Get
            Set(ByVal value As Integer)
                _Bottom = _Bottom - _Top + value
                _Top = value
            End Set
        End Property
        Public Property Left As Integer
            Get
                Return _Left
            End Get
            Set(ByVal value As Integer)
                _Left = value
            End Set
        End Property
        Public Property Top As Integer
            Get
                Return _Top
            End Get
            Set(ByVal value As Integer)
                _Top = value
            End Set
        End Property
        Public Property Right As Integer
            Get
                Return _Right
            End Get
            Set(ByVal value As Integer)
                _Right = value
            End Set
        End Property
        Public Property Bottom As Integer
            Get
                Return _Bottom
            End Get
            Set(ByVal value As Integer)
                _Bottom = value
            End Set
        End Property
        Public Property Height() As Integer
            Get
                Return _Bottom - _Top
            End Get
            Set(ByVal value As Integer)
                _Bottom = value + _Top
            End Set
        End Property
        Public Property Width() As Integer
            Get
                Return _Right - _Left
            End Get
            Set(ByVal value As Integer)
                _Right = value + _Left
            End Set
        End Property
        Public Property Location() As Point
            Get
                Return New Point(Left, Top)
            End Get
            Set(ByVal value As Point)
                _Right = _Right - _Left + value.X
                _Bottom = _Bottom - _Top + value.Y
                _Left = value.X
                _Top = value.Y
            End Set
        End Property
        Public Property Size() As Size
            Get
                Return New Size(Width, Height)
            End Get
            Set(ByVal value As Size)
                _Right = value.Width + _Left
                _Bottom = value.Height + _Top
            End Set
        End Property

        Public Shared Widening Operator CType(ByVal Rectangle As RECT) As Rectangle
            Return New Rectangle(Rectangle.Left, Rectangle.Top, Rectangle.Width, Rectangle.Height)
        End Operator
        Public Shared Widening Operator CType(ByVal Rectangle As Rectangle) As RECT
            Return New RECT(Rectangle.Left, Rectangle.Top, Rectangle.Right, Rectangle.Bottom)
        End Operator
        Public Shared Operator =(ByVal Rectangle1 As RECT, ByVal Rectangle2 As RECT) As Boolean
            Return Rectangle1.Equals(Rectangle2)
        End Operator
        Public Shared Operator <>(ByVal Rectangle1 As RECT, ByVal Rectangle2 As RECT) As Boolean
            Return Not Rectangle1.Equals(Rectangle2)
        End Operator

        Public Overrides Function ToString() As String
            Return "{Left: " & _Left & "; " & "Top: " & _Top & "; Right: " & _Right & "; Bottom: " & _Bottom & "}"
        End Function

        Public Overloads Function Equals(ByVal Rectangle As RECT) As Boolean
            Return Rectangle.Left = _Left AndAlso Rectangle.Top = _Top AndAlso Rectangle.Right = _Right AndAlso Rectangle.Bottom = _Bottom
        End Function
        Public Overloads Overrides Function Equals(ByVal [Object] As Object) As Boolean
            If TypeOf [Object] Is RECT Then
                Return Equals(DirectCast([Object], RECT))
            ElseIf TypeOf [Object] Is Rectangle Then
                Return Equals(New RECT(DirectCast([Object], Rectangle)))
            End If

            Return False
        End Function
    End Structure

    Public Function ChangeOpacity(ByVal img As Image, ByVal opacityvalue As Single) As Bitmap
        Dim bmp As New Bitmap(img.Width, img.Height)
        Dim graphics__1 As Graphics = Graphics.FromImage(bmp)
        Dim colormatrix As New ColorMatrix
        colormatrix.Matrix33 = opacityvalue
        Dim imgAttribute As New ImageAttributes
        imgAttribute.SetColorMatrix(colormatrix, ColorMatrixFlag.[Default], ColorAdjustType.Bitmap)
        graphics__1.DrawImage(img, New Rectangle(0, 0, bmp.Width, bmp.Height), 0, 0, img.Width, img.Height, _
         GraphicsUnit.Pixel, imgAttribute)
        graphics__1.Dispose()
        Return bmp
    End Function

End Module


Class cell

    Sub New(ByVal processid As Integer, ByVal snapshot As Bitmap, ByVal icon As Icon, ByVal windowtitle As String)
        _pid = processid
        _bgimg = snapshot
        _title = windowtitle
        _ico = icon
        mybmp = generateimg()
    End Sub
    Public mybmp As Bitmap
    Private _pid As Integer = 0
    Private _bgimg As Bitmap
    Private _title As String = ""
    Private _ico As Icon

    Public Property pid As Integer
        Get
            Return _pid
        End Get
        Set(ByVal value As Integer)
            _pid = value
        End Set
    End Property

    Public Property bgimg As Bitmap
        Get
            Return _bgimg
        End Get
        Set(ByVal value As Bitmap)
            _bgimg = value
        End Set
    End Property

    Public Property title As String
        Get
            Return _title
        End Get
        Set(ByVal value As String)
            _title = value
        End Set
    End Property

    Public Property ico As Icon
        Get
            Return _ico
        End Get
        Set(ByVal value As Icon)
            _ico = value
        End Set
    End Property

    Private _locX As Integer = 0
    Public Property locX As Integer
        Get
            Return _locX
        End Get
        Set(ByVal value As Integer)
            _locX = value
        End Set
    End Property

    Private _op As Integer = 100
    Public Property op As Integer
        Get
            Return _op
        End Get
        Set(ByVal value As Integer)
            _op = value
        End Set
    End Property
    Private _out As Boolean = False
    Public Property out As Boolean
        Get
            Return _out
        End Get
        Set(ByVal value As Boolean)
            _out = value
            If (_out = True) Then
                Dim t As New Threading.Thread(AddressOf Kill)
                t.IsBackground = True
                t.Start()
            End If
        End Set
    End Property
    Private Sub Kill()
        Try
            Process.GetProcessById(Me._pid).Kill()
        Catch : End Try
    End Sub
    Function generateimg() As Bitmap
        Dim b As New Bitmap(307, 120)
        Dim g As Graphics = Graphics.FromImage(b)
        g.SmoothingMode = Drawing2D.SmoothingMode.AntiAlias
        g.TextRenderingHint = Drawing.Text.TextRenderingHint.AntiAlias
        g.InterpolationMode = Drawing2D.InterpolationMode.HighQualityBicubic
        g.CompositingQuality = Drawing2D.CompositingQuality.HighQuality
        g.DrawImage(bgimg, New Rectangle(150, 10, 128, 100))
        g.DrawIcon(ico, New Rectangle(134, 16, 32, 32))
        g.DrawLine(Pens.White, New Point(10, 32), New Point(124, 32))
        g.DrawString(title, New Font("Microsoft Sans Serif", 8), Brushes.White, New Rectangle(10, 16, 124, 16), New StringFormat With {.FormatFlags = StringFormatFlags.LineLimit})
        Return b
    End Function

End Class
